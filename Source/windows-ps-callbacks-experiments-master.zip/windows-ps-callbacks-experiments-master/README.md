# windows-ps-callbacks-experiments

Files for http://deniable.org/windows/windows-callbacks

**Warning**: Windows 10 19H1 x64 only
