More information can be found here: https://medium.com/@aviadshamriz/part-1-fs-minifilter-hooking-7e743b042a9d 
